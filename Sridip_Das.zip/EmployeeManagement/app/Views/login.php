<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            margin-top: 10px;
            display: block;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
            text-align: center;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="error"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <form id="loginForm" action="/auth/loginSubmit" method="post" onsubmit="return validateForm()">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required minlength="3" maxlength="20" pattern="^[a-zA-Z0-9_]+$" title="Username must be 3-20 characters long and can only contain letters, numbers, and underscores.">
            
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required minlength="6" title="Password must be at least 6 characters long.">
            
            <button type="submit">Login</button>
        </form>
    </div>

    <script>
        function validateForm() {
            const username = document.getElementById('username');
            const password = document.getElementById('password');
            
            if (!username.checkValidity()) {
                alert(username.title);
                username.focus();
                return false;
            }

            if (!password.checkValidity()) {
                alert(password.title);
                password.focus();
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
