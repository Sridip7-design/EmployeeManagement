<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            margin-top: 10px;
            display: block;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            margin-top: 20px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .current-picture {
            margin: 10px 0;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #4CAF50;
        }

        img {
            border-radius: 5px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Employee</h1>
        <form action="/employees/update/<?= $employee['id'] ?>" method="post" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" name="name" value="<?= $employee['name'] ?>" required>
            
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?= $employee['address'] ?>" required>
            
            <label for="designation">Designation:</label>
            <input type="text" name="designation" value="<?= $employee['designation'] ?>" required>
            
            <label for="salary">Salary:</label>
            <input type="number" name="salary" value="<?= $employee['salary'] ?>" required>
            
            <label>Current Picture:</label>
            <img src="/uploads/<?= $employee['picture'] ?>" alt="Current Picture" width="50" class="current-picture">
            
            <label for="picture">New Picture:</label>
            <input type="file" name="picture">
            
            <input type="submit" value="Update Employee">
        </form>
        <a href="/employees" class="back-link">Back to Employee List</a>
    </div>
</body>
</html>
