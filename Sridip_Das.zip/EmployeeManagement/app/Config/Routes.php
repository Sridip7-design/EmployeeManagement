<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/','Auth::login');
$routes->post('/auth/loginSubmit','Auth::loginSubmit');
$routes->get('/auth/logout','Auth::logout');
$routes->get('/employees', 'Employee::index');
$routes->get('/employees/create', 'Employee::create');
$routes->post('/employees/store', 'Employee::store');
$routes->get('/employees/edit/(:num)', 'Employee::edit/$1');
$routes->post('/employees/update/(:num)', 'Employee::update/$1');
$routes->get('/employees/delete/(:num)', 'Employee::delete/$1');

