<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Employee extends Controller
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $query = $this->db->query("SELECT * FROM emp_details");
        $data['employees'] = $query->getResultArray();
        return view('employee_list', $data);
    }

    public function create()
    {
        return view('create_employee');
    }

    public function store()
    {
        $name = $this->request->getPost('name');
        $address = $this->request->getPost('address');
        $designation = $this->request->getPost('designation');
        $salary = $this->request->getPost('salary');
        
        // Handle picture upload
        $picture = $this->request->getFile('picture');
        $pictureName = '';
        if ($picture->isValid() && !$picture->hasMoved()) {
            $pictureName = $picture->getRandomName();
            $picture->move('uploads', $pictureName);
        }

        $this->db->query("INSERT INTO emp_details (name, address, designation, salary, picture) VALUES (?, ?, ?, ?, ?)", 
            [$name, $address, $designation, $salary, $pictureName]);

        return redirect()->to('/employees')->with('success', 'Employee created successfully');
    }

    public function edit($id)
    {
        $query = $this->db->query("SELECT * FROM emp_details WHERE id = ?", [$id]);
        $data['employee'] = $query->getRowArray();
        return view('edit_employee', $data);
    }

    public function update($id)
    {
        $name = $this->request->getPost('name');
        $address = $this->request->getPost('address');
        $designation = $this->request->getPost('designation');
        $salary = $this->request->getPost('salary');
        
        // Handle picture upload
        $picture = $this->request->getFile('picture');
        $pictureName = '';
        if ($picture->isValid() && !$picture->hasMoved()) {
            $pictureName = $picture->getRandomName();
            $picture->move('uploads', $pictureName);
        }

        // Update the employee record
        $this->db->query("UPDATE emp_details SET name = ?, address = ?, designation = ?, salary = ?, picture = ? WHERE id = ?", 
            [$name, $address, $designation, $salary, $pictureName ?: $this->getCurrentPicture($id), $id]);

        return redirect()->to('/employees')->with('success', 'Employee updated successfully');
    }

    public function delete($id)
    {
        $this->db->query("DELETE FROM emp_details WHERE id = ?", [$id]);
        return redirect()->to('/employees')->with('success', 'Employee deleted successfully');
    }

    private function getCurrentPicture($id)
    {
        $query = $this->db->query("SELECT picture FROM emp_details WHERE id = ?", [$id]);
        return $query->getRowArray()['picture'];
    }
}
