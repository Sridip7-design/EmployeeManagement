<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\Database\ConnectionInterface;

class Auth extends Controller
{
    protected $db;

    public function __construct()
    {
        // Database connection
        $this->db = \Config\Database::connect();
    }

    public function login()
    {
        return view('login');
    }

    public function loginSubmit()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // User check in database
        $query = $this->db->query("SELECT * FROM login_details WHERE user_name = ?", [$username]);
        $user = $query->getRowArray();

        if ($user) {
            // User exists, verify password
            if (password_verify($password, $user['password'])) {
                session()->set('logged_in', true);
                session()->set('user_name', $user['user_name']);
                return redirect()->to('/employees'); // Redirect to dashboard
            } else {
                return redirect()->to('/')->with('error', 'Invalid password');
            }
        } else {
            // User does not exist, register
            $this->registerUser($username, $password);
            return redirect()->to('/employees'); // Redirect after registration
        }
    }

    private function registerUser($username, $password)
    {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user into database
        $this->db->query("INSERT INTO login_details (user_name, password, name) VALUES (?, ?, ?)", [$username, $hashedPassword, $username]);

        session()->set('logged_in', true);
        session()->set('user_name', $username);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
